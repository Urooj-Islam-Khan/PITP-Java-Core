import java.util.Scanner;

public class AC1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AC2 ac = new AC2();
        System.out.println("What you want");
        System.out.println("1: Cooling");
        System.out.println("2: Heating");

        int ans = sc.nextInt();

        switch (ans) {
            case 1:
                ac.Cooling();
                break;
            case 2:
                ac.Heating();
                ;
                break;

            default:
                break;
        }
    }
}
