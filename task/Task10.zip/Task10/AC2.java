public class AC2 {

    public void Cooling() {
        System.out.println("Cooling");
    }

    public void Heating() {
        System.out.println("Heating");
    }
}
